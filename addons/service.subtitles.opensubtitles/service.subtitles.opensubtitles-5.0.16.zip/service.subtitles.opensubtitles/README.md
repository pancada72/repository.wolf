OpenSubtitles.org KODI add-on
=============================
Search and download subtitles for movies and TV-Series from OpenSubtitles.org. Search in 75 languages, 4.000.000+ subtitles, daily updates.
                            
Changelog


5.0.16
- Changed descriptions, icons, fanart... (by opensubtitles)

5.0.15
- disable anonymous login, users need to register on opensubtitles.org and login in addon settings.

5.0.14
- Fix for Portuguese (Brazil) broken by 42f6ec9, thx host505

5.0.13
- Fix for Greek subtitles, thx host505

5.0.12
- compare season and episode and display only matching results

5.0.11
- fix: search issues
- cosmetics
- add slash or backslash at the end of path (fix xbmcvfs.exists in Helix), thx Ondrej Bima

5.0.10
- fix: Don't unquote(urldecode) file_original_path as it breaks http file hashing, thx arnova

5.0.9
- fix hash large rars, Beam
- Support for preferred language sorting and fetch using IMDBID, Glenn Jennehed
- fix: hack to work around issue where Brazilian is not found as language in XBMC

5.0.8
- fix: extension is needed for downloaded files

5.0.7
- fix: Do not use unsafe file names, thx Cesar Canassa

5.0.6
- clean temp folder
- add login details to addon settings

5.0.5
- [fix] ascii UNICODE.decode
- [fix] manual search string unquoted
- cosmetics and code simplification

5.0.4
- manual search button support

5.0.3
- fix Portuguese (Brazil) and Greek

5.0.2
- icon.png and added logo.png for skin to use in window

5.0.1
- let skin control flag filetype

5.0.0
- move the service out of XBMC Subtitles